<?php
session_start();
if (!isset($_SESSION['login'])) {
    header ("location:login.php?pesan=login");
}
include "koneksi.php";
$sql = "SELECT * FROM post";
$query = mysqli_query($koneksi,$sql);
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="Stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-Hj1245DjiE3f4z8nWo+5Xl5XlFL4AHfFOw5FyKbE6d1pLk2feMvE2tRGp5F5XOjWl" crossorigin="anonymous"></script>
    <link rel="icon" href="logo.png" type="image/x-icon">
    <title>Lanagram</title>
    
    <style>
        .card-img-top {
            transition: transform 0.3s;
        }

        .card-img-top:hover {
            transform: scale(1.1);
        }
    </style>
    <title>Hoverable Sidebar Menu HTML CSS & JavaScript</title>
    <link rel="stylesheet" href="style.css" />
    <!-- Boxicons CSS -->
    <link flex href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet" />
    <script src="script.js" defer></script>
  </head>
  <body>
    <nav class="sidebar locked">
      <div class="logo_items flex">
        <span class="nav_image">
          <img src="logo.png" alt="logo_img" />
        </span>
        <span class="logo_name">CoffeGram</span>
        <i class="bx bx-lock-alt" id="lock-icon" title="Unlock Sidebar"></i>
        <i class="bx bx-x" id="sidebar-close"></i>
      </div>

      <div class="menu_container">
        <div class="menu_items">
          <ul class="menu_item">
            <div class="menu_title flex">
              <span class="title">Dashboard</span>
              <span class="line"></span>
            </div>
            <li class="item">
              <a href="index.php" class="link flex">
              <i class="fa-solid fa-house"></i>
                <span>Beranda</span>
              </a>
            </li>
            <li class="item">
              <a href="#" class="link flex">
              <i class="fas fa-compass"></i>
                <span>Jelajahi</span>
              </a>
            </li>
            <li class="item">
              <a href="#" class="link flex">
              <i class="fa-solid fa-video"></i>
                <span>Reels</span>
              </a>
            </li>
          </ul>

          <ul class="menu_item">
            <div class="menu_title flex">
              <span class="title">Editor</span>
              <span class="line"></span>
            </div>
            <li class="item">
              <a href="#" class="link flex">
              <i class="fa-solid fa-bell"></i>
                <span>Notifikasi</span>
              </a>
            </li>
            <li class="item">
              <a href="#" class="link flex">
              <i class="fa-solid fa-message"></i>
                <span>Pesan</span>
              </a>
            </li>
            <button type="button" data-bs-toggle="modal" data-bs-target="#exampleModal" style="color: white; background-color: transparent; border: none;">
                <i class="bx bx-cloud-upload"></i>
                <span>New</span>
            </button>
          </ul>
 
          <ul class="menu_item">
            <div class="menu_title flex">
              <span class="title">Setting</span>
              <span class="line"></span>
            </div>
            <li class="item">
              <a href="logout.php" class="link flex">
              <i class="fa-solid fa-right-from-bracket"></i>
                <span>Logout</span>
              </a>
            </li>
            <li class="item">
              <a href="#" class="link flex">
                <i class="bx bx-cog"></i>
                <span>Setting</span>
              </a>
            </li>
          </ul>
        </div>

        <div class="sidebar_profile flex">
          <span class="nav_image">
            <img src="Lana Del Rey.jpeg" alt="logo_img" />
          </span>
          <div class="data_text">
            <span class="name">Admin</span>
          </div>
        </div>
      </div>
    </nav>

 <!-- main content -->
 <div class="container mt-3"><br>
    <div class="row">
        <?php while ($post = mysqli_fetch_assoc($query)) { ?>
            <center>
                <div class="zoom">
                </div>
        <div class="col-sm-6">
            <div class="card">
                <div class="zoom">
                <img src="images/<?=$post['foto']?>" alt="" width="25px" id="card" class="card-img-top">
                </div>
                
            </div>
        </div><br><br>
        </center>
        <?php }
