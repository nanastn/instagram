<?php
session_start();
if (!isset($_SESSION['login'])) {
    header ("location:login.php?pesan=login");
}
include "koneksi.php";
$sql = "SELECT * FROM post ORDER BY no DESC";
$query = mysqli_query($koneksi,$sql);
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="Stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-Hj1245DjiE3f4z8nWo+5Xl5XlFL4AHfFOw5FyKbE6d1pLk2feMvE2tRGp5F5XOjWl" crossorigin="anonymous"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <link rel="icon" href="logo.png" type="image/x-icon">
    <title>CoffeGram</title>
    <style>
        .card-img-top {
            transition: transform 0.3s;
        }

        .card-img-top:hover {
            transform: scale(1.1);
        }
    </style>
    <link rel="stylesheet" href="style.css" />
    <!-- Boxicons CSS -->
    <link flex href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet" />
    <script src="script.js" defer></script>
  </head>
  <body>
    <nav class="sidebar locked">
      <div class="logo_items flex">
        <span class="nav_image">
          <img src="logo.png" alt="logo_img" />
        </span>
        <span class="logo_name">CoffeGram</span>
        <i class="bx bx-lock-alt" id="lock-icon" title="Unlock Sidebar"></i>
        <i class="bx bx-x" id="sidebar-close"></i>
      </div>

      <div class="menu_container">
        <div class="menu_items">
          <ul class="menu_item">
            <div class="menu_title flex">
              <span class="title">Dashboard</span>
              <span class="line"></span>
            </div>
            <li class="item">
              <a href="index.php" class="link flex">
              <i class="fa-solid fa-house"></i>
                <span>Beranda</span>
              </a>
            </li>
            <li class="item">
              <a href="jelajahi.php" class="link flex">
              <i class="fas fa-compass"></i>
                <span>Jelajahi</span>
              </a>
            </li>
            <li class="item">
              <a href="#" class="link flex">
              <i class="fa-solid fa-video"></i>
                <span>Reels</span>
              </a>
            </li>
          </ul>

          <ul class="menu_item">
            <div class="menu_title flex">
              <span class="title">Editor</span>
              <span class="line"></span>
            </div>
            <li class="item">
              <a href="#" class="link flex">
              <i class="fa-solid fa-bell"></i>
                <span>Notifikasi</span>
              </a>
            </li>
            <li class="item">
              <a href="#" class="link flex">
              <i class="fa-solid fa-message"></i>
                <span>Pesan</span>
              </a>
            </li>
            <li class="item">
            <button type="button" data-bs-toggle="modal" data-bs-target="#exampleModal" style="color: black; background-color: transparent; border: none;">
            <i class="fa-solid fa-square-plus"></i>
                <span>New</span>
            </button>
            </li>
          </ul>
 
          <ul class="menu_item">
            <div class="menu_title flex">
              <span class="title">Setting</span>
              <span class="line"></span>
            </div>
            <li class="item">
              <a href="logout.php" class="link flex">
              <i class="fa-solid fa-right-from-bracket"></i>
                <span>Logout</span>
              </a>
            </li>
            <li class="item">
              <a href="#" class="link flex">
                <i class="bx bx-cog"></i>
                <span>Setting</span>
              </a>
            </li>
          </ul>
        </div>

        <div class="sidebar_profile flex">
          <span class="nav_image">
            <img src="Lana Del Rey.jpeg" alt="logo_img" />
          </span>
          <div class="data_text">
            <span class="name">Admin</span>
          </div>
        </div>
      </div>
    </nav>

    <!-- main content -->
    <div class="container mt-3"><br>
    <div class="row">
        <?php while ($post = mysqli_fetch_assoc($query)) { ?>
            <center>
                <div class="zoom">
                </div>
        <div class="col-sm-6 mb-2">
            <div class="card">
                <div class="zoom">
                <img src="images/<?=$post['foto']?>" alt="" width="50px" id="card" class="card-img-top">
                </div>
                <div class="card-body">
                    <p class="card-text"><?=$post['caption']?></p>
                    <p class="card-text"><?=$post['lokasi']?></p>
                    <hr>
                    <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#staticBackdrop<?=$post['no']?>"><i class="fa-solid fa-pen"></i></button>
                    <a href="hapus.php?no=<?=$post['no']?>" onclick="return confirm('hapus postingan ini?')"><button class="btn btn-danger" title="Hapus data" type="button"><i class="fas fa-trash"></i></button></a>
                </div>
            </div>
        </div><br><br>
        </center>

    <!-- Modal  -->
    
    <div class="modal fade" id="staticBackdrop<?=$post['no']?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
        aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                    <h1 class="modal-title fs-5" id="staticBackdropLabel">EDIT POSTINGAN</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                <form action="proses_edit.php" method="post" enctype="multipart/form-data">
        <input type="hidden" name="no" value="<?= $post['no'] ?>">
        <input type="hidden" name="foto_lama" value="<?= $post['foto'] ?>" class="form-control">
        <br>
        <label for="">Foto</label>
        <input type="file" name="foto" id="" value="<?= $post['foto'] ?>" class="form-control"><br>
        <img src="images/<?= $post['foto'] ?>" width="100" alt=""><br><br>
        <label for="">Caption</label>
        <input type="text" name="caption" id="" value="<?= $post['caption'] ?>" class="form-control" autocomplete="off"><br>
        <label for="">Lokasi</label>
        <input type="text" name="lokasi" id="" value="<?= $post['lokasi'] ?>" class="form-control" autocomplete="off"><br>
        
        <input type="submit" value="Update" name="update" class="btn btn-primary"><br>
        
    </form>
        </div>
    <div class="modal-footer">
    </div>
    </div>
            </div>
        </div>
</div>
        <?php } ?>
    </div>
    </div>
    </div>
</div><br><br>

<!-- Modal --><!-- Modal -->

<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="exampleModalLabel">TAMBAH POSTINGAN</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="proses_tambah.php" method="post" enctype="multipart/form-data" autocomplete="off">
                    <div class="form-group">
                        <label for="foto">Foto</label>
                        <input type="file" class="form-control" name="foto" id="foto" required>
                    </div>
                    <div class="form-group">
                        <label for="caption">Caption</label>
                        <input type="text" class="form-control" name="caption" id="caption" autocomplete="off">
                    </div>
                    <div class="form-group">
                        <label for="lokasi">Lokasi</label>
                        <input type="text" class="form-control" name="lokasi" id="lokasi" autocomplete="off">
                    </div>
                    <button type="submit" class="btn btn-primary" name="simpan">Upload</button>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- JavaScript -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha384-KyZXEAg3QhqLMpG8r+5qT1Np5E5z5/zj5z6f5U9FmkD5FFPj6b5f5/I5z5v5I5t5y5z5" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-zEnz5zg9a8Q4S5rlf5M2ac3zU5/2A2b9TK7E3datnE3f5P1e5w5/y5v5m5v5m5v5g5" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
    <!-- jangan lupa menambahkan script js sweet alert di bawah ini  -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.33.1/sweetalert2.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
<?php if(@$_SESSION['sukses']){ ?>
<script>
    Swal.fire({
        icon: 'success',
        title: 'Good job!',
        text: '<?php echo $_SESSION['sukses']; ?>',
    });
</script>
<?php unset($_SESSION['sukses']); } ?>

<script>
    $(document).ready(function () {
        // Tombol Tutup Sidebar
        $('#closeSidebar').click(function () {
            // Tambahkan kelas 'collapsed' ke sidebar
            $('.sidebar').addClass('collapsed');
        });

        // Tombol Buka Sidebar (opsional)
        $('#openSidebar').click(function () {
            // Hapus kelas 'collapsed' dari sidebar
            $('.sidebar').removeClass('collapsed');
        });
    });
</script>
<script>
    $(document).ready(function () {
        $('.btn-edit').on('click', function () {
            var no = $(this).data('no');
            var caption = $(this).data('caption');
            var lokasi = $(this).data('lokasi');

            $('#edit_no').val(no);
            $('#edit_caption').val(caption);
            $('#edit_lokasi').val(lokasi);

            $('#editModal').modal('show');
        });
    });
</script>
</html>
